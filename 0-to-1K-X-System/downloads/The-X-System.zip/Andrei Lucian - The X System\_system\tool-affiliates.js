/**
 * Tool stack + affiliate links — edit URLs here only.
 * Get affiliate links from each tool's partner / referral program.
 */
window.X1K_TOOLS = {
  affiliateNote:
    "Links marked ↗ may be affiliate links. I only recommend tools I use weekly — never pay for something you don't need.",

  free: [
    {
      name: "X (Twitter)",
      role: "Your platform — post, reply, threads, DMs",
      note: "Free tier is enough for the full 90-day system.",
    },
    {
      name: "Notion",
      role: "Idea bank · 90-day planner · winners vault",
      note: "Free plan works. One page called Post Ideas is enough to start.",
    },
    {
      name: "ChatGPT",
      role: "Hook variations · outline drafts · template remixes",
      note: "Free tier is fine. Always rewrite in your voice before posting.",
    },
  ],

  paid: [
    {
      name: "Hypefury",
      when: "Add in Week 2+ when you're posting daily",
      forWhat: "Schedules your posts so you're never staring at a blank publish button.",
      bullets: [
        "Queue 7–14 days of posts in one 45-minute batch session",
        "Auto-retweet your best posts 6 hours later for a second wave of reach",
        "Engagement lists — pull up the 20 accounts you reply to every morning",
      ],
      url: "https://hypefury.com/?via=YOUR_AFFILIATE_ID",
      cta: "Get Hypefury ↗",
    },
    {
      name: "Typefully",
      when: "Alternative to Hypefury — pick one scheduler, not both",
      forWhat: "Write and schedule X threads + posts in a clean editor built for creators.",
      bullets: [
        "Draft threads with a visual preview before you publish",
        "Schedule posts for your best posting times without opening X",
        "Analytics on which hooks and threads actually performed",
      ],
      url: "https://typefully.com/?via=YOUR_AFFILIATE_ID",
      cta: "Get Typefully ↗",
    },
  ],

  scale: [
    {
      name: "Kit",
      when: "After 250+ followers when you want an email list",
      forWhat: "Turns profile visitors into subscribers — so growth isn't trapped on X.",
      bullets: [
        "Landing page + opt-in form for your lead magnet (cheatsheet, playbook, etc.)",
        "Automated welcome email when someone joins your list",
        "Broadcast to your list when you launch a product or raise prices",
      ],
      url: "https://kit.com?lmref=YOUR_AFFILIATE_ID",
      cta: "Get Kit ↗",
    },
    {
      name: "Sales Navigator",
      when: "After 500+ followers — B2B / LinkedIn outreach",
      forWhat: "Find founders and decision-makers for DMs and partnerships.",
      bullets: [
        "Advanced search filters by title, company size, and industry",
        "InMail credits when you're not connected yet",
        "Save lead lists for weekly outreach blocks",
      ],
      url: "https://business.linkedin.com/sales-solutions/sales-navigator",
      cta: "Learn about Sales Navigator ↗",
      affiliate: false,
    },
  ],
};
